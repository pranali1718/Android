package com.pfmmmad.pranali;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import androidx.annotation.Nullable;
public class NewService extends Service {
    private MediaPlayer music;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        music.stop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        music = MediaPlayer.create(this, R.raw.music);
        music.setLooping(true);
        music.start();

        return START_STICKY;
    }
}
