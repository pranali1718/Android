package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class cdialogbox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cdialogbox);
        //ImageButton close =(ImageButton) d.findViewById()
            showDialog();
        }
        private void showDialog()
        {
            Dialog d = new Dialog(this);
            d.setContentView(R.layout.dialogfile);


            Button btn=(Button) d.findViewById(R.id.p);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    d.dismiss();
                }
        });
        d.show();
    }
}