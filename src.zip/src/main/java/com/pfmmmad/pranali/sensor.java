package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class sensor extends AppCompatActivity {
TextView txt = null;
private SensorManager mSensorManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        txt = (TextView) findViewById(R.id.pranali);
        txt.setVisibility(View.GONE);

        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        List<Sensor> mList = mSensorManager.getSensorList(Sensor.TYPE_ALL);

        for(int i =1;i<mList.size();i++)
        {
            txt.setVisibility(View.VISIBLE);
            txt.append("\n"+ mList.get(i).getName());
        }


    }
}