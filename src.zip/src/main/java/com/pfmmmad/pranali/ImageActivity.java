package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class ImageActivity extends AppCompatActivity
{
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        image=(ImageView) findViewById(R.id.image1);

        Intent i = getIntent();
        String action = i.getAction();
        String type = i.getType();
        if(Intent.ACTION_SEND.equals(action) && type != null)
        {
            image.setImageURI(i.getParcelableExtra(Intent.EXTRA_STREAM));
        }

    }
}