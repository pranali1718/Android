package com.pfmmmad.pranali;

//import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class LogActivity extends AppCompatActivity
{
    public static final String LOG_TAG = "LogActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);



        setTitle("Log Activity");

            Log.v(LOG_TAG,"This is verbose log");

            Log.d(LOG_TAG,"This is debug log");

            Log.i(LOG_TAG,"This is info log");

            Log.w(LOG_TAG,"This is warn log");

            Log.e(LOG_TAG,"This is error log");
    }
}