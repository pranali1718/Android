package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("LogActivity","OnCreate method called");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("LogActivity","OnStart method called");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("LogActivity","OnStop method called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("LogActivity","OnRestart method called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("LogActivity","OnDestroy method called");
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.d("LogActivity","OnPause method called");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("LogActivity","OnResume method called");
    }
}