package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class ProximityActivity extends AppCompatActivity implements SensorEventListener{
    TextView txt = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proximity);

        SensorManager sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show();
        txt = (TextView) findViewById(R.id.pranali1);
        if(sensorManager !=null)
        {
            Sensor proximitysensor =  sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            if(proximitysensor !=null)
            {
                sensorManager.registerListener((SensorEventListener) this,proximitysensor,sensorManager.SENSOR_DELAY_NORMAL);
            }
        }
        else
        {
            Toast.makeText(this,"Sensor service not detected", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        if(sensorEvent.sensor.getType()==Sensor.TYPE_PROXIMITY)
        {
            txt.setText("Proximity: "+sensorEvent.values[0]);
        }

        if(sensorEvent.values[0]>0)
        {
            WindowManager.LayoutParams params = getWindow().getAttributes();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}