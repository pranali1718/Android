package com.pfmmmad.pranali;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Implicit_activity extends AppCompatActivity {

    Button implicit,implicit2;
    EditText mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_implicit);
        setTitle("Intent Page");

        implicit=(Button) findViewById(R.id.button3);
        implicit2=(Button) findViewById(R.id.button4);

        implicit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent implicit =new Intent(Intent.ACTION_VIEW);

                implicit.setData(Uri.parse("https://www.mongodb.com/try/download/community"));
                startActivity(implicit);


            }
        });

        implicit2.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View view)
            {
                String text="Hello...";
                Intent implicit2 =new Intent(Intent.ACTION_SEND);
                implicit2.setType("text/plain");
                implicit2.putExtra(Intent.EXTRA_TEXT,text);
                startActivity(Intent.createChooser(implicit2,"suggest to your frnnd"));
            }
        });

        /*mail.setOnClickListener(new View.OnClickListener()
         {
            @Override
            public void onClick(View view)
            {

                Intent mail=new Intent(Intent.ACTION_SEND,Uri.parse("mailto:"));
                mail.setType("message");
                boolean recipients = true;
                //boolean subject = true;
                mail.putExtra(Intent.EXTRA_EMAIL,recipients);
               // mail.putExtra(Intent.EXTRA_SUBJECT,subject.getText().toString());

            }
        });*/

    }
}